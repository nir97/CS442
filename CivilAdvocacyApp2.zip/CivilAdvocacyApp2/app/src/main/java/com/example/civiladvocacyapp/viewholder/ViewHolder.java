package com.example.civiladvocacyapp.viewholder;

import android.view.View;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.civiladvocacyapp.R;
import com.example.civiladvocacyapp.model.Official;


public class ViewHolder extends RecyclerView.ViewHolder {

    /*private Context context;*/
    private final TextView tvOfficialDesignation;
    private final TextView tvOfficialName;
    /*private final ConstraintLayout recyclerViewRow;*/

    public ViewHolder(@NonNull View itemView/*, Context context*/) {
        super(itemView);
        /*this.context = context;*/

        tvOfficialDesignation = itemView.findViewById(R.id.tvOfficialDesignation);
        tvOfficialName = itemView.findViewById(R.id.tvOfficialName);
        /*recyclerViewRow = itemView.findViewById(R.id.recyclerViewRow);*/
    }

    public void bind(Official official) {
        tvOfficialDesignation.setText(official.getOffice());

        if ("No data provided".equalsIgnoreCase(official.getOfficialParty()) ||
                "Unknown".equalsIgnoreCase(official.getOfficialParty())) {
            tvOfficialName.setText(official.getOfficialName());
        } else {
            tvOfficialName.setText(String.format("%s (%s)", official.getOfficialName(), official.getOfficialParty()));
        }

        /*recyclerViewRow.setOnClickListener((View.OnClickListener) v -> {
            Intent intent = new Intent(context, OfficialActivity.class);
            //intent.putExtra(context.getString(R.string.location), tvLocation.getText());
            intent.putExtra(Official.class.getName(), official);

            Pair<View, String> p1 = Pair.create((View) tvOfficialDesignation, context.getString(R.string.official_designation));
            Pair<View, String> p2 = Pair.create((View) tvOfficialName, context.getString(R.string.official_name));
            ActivityOptionsCompat options = ActivityOptionsCompat.makeSceneTransitionAnimation((Activity) context, p1, p2);
            context.startActivity(intent, options.toBundle());
        });*/
    }
}
