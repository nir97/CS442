package com.example.civiladvocacyapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.civiladvocacyapp.MainActivity;
import com.example.civiladvocacyapp.R;
import com.example.civiladvocacyapp.model.Official;
import com.example.civiladvocacyapp.viewholder.ViewHolder;

import java.util.List;


public class RecyclerViewAdapter extends RecyclerView.Adapter<ViewHolder> {

    private final List<Official> officials;
    private final MainActivity mainActivity;

    public RecyclerViewAdapter(MainActivity mainActivity, List<Official> officials) {
        this.mainActivity = mainActivity;
        this.officials = officials;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_view_row, parent, false);
        view.setOnClickListener(mainActivity);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Official official = officials.get(position);
        holder.bind(official);
    }

    @Override
    public int getItemCount() {
        return officials.size();
    }
}
