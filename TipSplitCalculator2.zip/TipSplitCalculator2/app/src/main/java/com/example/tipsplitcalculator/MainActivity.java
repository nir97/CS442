package com.example.tipsplitcalculator;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.text.BreakIterator;
import java.text.DecimalFormat;

import static android.widget.Toast.*;
import static android.widget.Toast.makeText;

public class MainActivity extends AppCompatActivity {




//    public TextView conversionHistory ;
//    public TextView fromLabel;
//    public TextView toLabel;

    public EditText billTotalWithTaxNumberInputText;
    public TextView tipAmountNumberEditText;
    public TextView totalWithTipNumberEditText;
    public EditText numberOfPeopleNumberInputText;
    public TextView totalPerPersonNumberEditText;
    public TextView overageNumberEditText;

    public RadioGroup radioGroup;
    public RadioButton twe;

    public Button goButton;

//    DecimalFormat resultFormat = new DecimalFormat("0.0");

    private SharedPreferences preferences;


    @SuppressLint({"CutPasteId", "DefaultLocale"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize fromEditText and toEditText and radio buttons

        billTotalWithTaxNumberInputText = (EditText)findViewById(R.id.billTotalWithTaxNumber);
        tipAmountNumberEditText = (TextView)findViewById(R.id.tipAmountNumber);
        totalWithTipNumberEditText = (TextView)findViewById(R.id.totalWithTipNumber);
        numberOfPeopleNumberInputText = (EditText)findViewById(R.id.numberOfPeopleNumber);
        totalPerPersonNumberEditText = (TextView)findViewById(R.id.totalPerPersonNumber);
        overageNumberEditText = (TextView)findViewById(R.id.overageNumber);

        goButton = (Button)findViewById(R.id.go);

        radioGroup = (RadioGroup) findViewById(R.id.radioGroupPercent);
//        twe = (RadioButton)findViewById(R.id.twelve);
//        RadioButton fif = (RadioButton)findViewById(R.id.fifteen);
//        RadioButton eig = (RadioButton)findViewById(R.id.eighteen);
//        RadioButton twen = (RadioButton)findViewById(R.id.twenty);


        radioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener()
        {


            double tip = 0;
            double totalAmount = 0;

            public void onCheckedChanged(RadioGroup radioGroup, int checkedId) {
//                System.out.println("HI"+checkedId);
                String valueStr = billTotalWithTaxNumberInputText.getText().toString();
                if(valueStr.isEmpty()){
                    Toast.makeText(MainActivity.this,"Enter your Values!", LENGTH_SHORT).show();
                    return;

                }
                double value = Double.parseDouble(valueStr);
                //                    Toast.makeText( this, "Please Enter Valid Amount!",Toast.LENGTH_LONG).show();
                if(value<0){
                    Toast.makeText(MainActivity.this,"Error! Please Enter Valid Amount", LENGTH_SHORT).show();
                    return;
                }
                else{
                switch(checkedId) {
                    case R.id.twelve:
                        tip = (value * 12) / 100;
                        totalAmount = value + tip;
                        break;
                    case R.id.fifteen:
                        tip = (value * 15) / 100;
                        totalAmount = value + tip;
                        break;
                    case R.id.eighteen:
                        tip = (value * 18) / 100;
                        totalAmount = value + tip;
                        break;
                    case R.id.twenty:
                        tip = (value * 20) / 100;
                        totalAmount = value + tip;
                        break;
                    default:
                        break;
                }
                }
                tipAmountNumberEditText.setText(String.format("$%.02f", tip));
                totalWithTipNumberEditText.setText(String.format("$%.02f", totalAmount));


            }
        });


    }


//    @SuppressLint("DefaultLocale")
//    public void radioClick(View v) {
//
//        String valueStr = billTotalWithTaxNumberInputText.getText().toString();
//
//        if (valueStr.matches("")) {
//            Toast.makeText(this, "You did not enter a bill amount", Toast.LENGTH_SHORT).show();
//            return;
//        }
//        float value = Float.parseFloat(valueStr);
//
//        RadioButton twe = (RadioButton)findViewById(R.id.twelve);
//        RadioButton fif = (RadioButton)findViewById(R.id.fifteen);
//        RadioButton eig = (RadioButton)findViewById(R.id.eighteen);
//        RadioButton twen = (RadioButton)findViewById(R.id.twenty);
//
//        float tip = 0;
//        float totalAmount = 0;
//
//        if (twe.isChecked()){
//            tip = value * 12 / 100;
//            totalAmount=value+tip;
//        }else if (fif.isChecked()){
//            tip = value * 15 / 100;
//            totalAmount=value+tip;
//        }else if (eig.isChecked()){
//            tip = value * 18 / 100;
//            totalAmount=value+tip;
//        }else if (twen.isChecked()){
//            tip = value * 20 / 100;
//            totalAmount=value+tip;
//        }

//
//    }

    @SuppressLint("DefaultLocale")
    public void go(View v){

        double avg =0;
        double overage= 0;
        String people = numberOfPeopleNumberInputText.getText().toString();
        if (people.isEmpty()) {
            Toast.makeText(this, "Sorry, Error!", LENGTH_SHORT).show();
            return;

        }
        int noPeople = Integer.parseInt(people);
        if (noPeople<=0 ){
            Toast.makeText(this,"Please Enter Valid People! ", LENGTH_SHORT).show();
            return;
        }
        else {

            String total = totalWithTipNumberEditText.getText().toString();
            total = total.substring(1);
            if (total.isEmpty()) {
                return;
            }

            double totalAmount = Double.parseDouble(total);
            avg = totalAmount / (double) noPeople;
            avg = (Math.round(avg * 100)) / 100.0;
            totalPerPersonNumberEditText.setText(String.format("$%.2f", avg));

            overage = Math.abs((avg * noPeople) - totalAmount);
            overageNumberEditText.setText(String.format("$%.02f", overage));
        }


    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {


        outState.putString("overageNumber", overageNumberEditText.getText().toString().trim());
        outState.putString("totalPerPersonNumber", totalPerPersonNumberEditText.getText().toString().trim());
        outState.putString("billTotalWithTaxNumber", billTotalWithTaxNumberInputText.getText().toString().trim());
        outState.putString("totalWithTipNumber", totalWithTipNumberEditText.getText().toString().trim());
        outState.putString("tipAmountNumber", tipAmountNumberEditText.getText().toString().trim());
        outState.putString("numberOfPeopleNumber", numberOfPeopleNumberInputText.getText().toString().trim());

        outState.putInt("radioGroupPercent", radioGroup.getCheckedRadioButtonId());


        // Call super last
        super.onSaveInstanceState(outState);
    }

    @Override
    protected void onRestoreInstanceState(@NonNull Bundle savedInstanceState) {
        // Call super first
        super.onRestoreInstanceState(savedInstanceState);


        overageNumberEditText.setText( savedInstanceState.getString("overageNumber"));
        totalPerPersonNumberEditText.setText( savedInstanceState.getString("totalPerPersonNumber"));
        billTotalWithTaxNumberInputText.setText( savedInstanceState.getString("billTotalWithTaxNumber"));

        totalWithTipNumberEditText.setText( savedInstanceState.getString("totalWithTipNumber"));
        tipAmountNumberEditText.setText( savedInstanceState.getString("tipAmountNumber"));
        numberOfPeopleNumberInputText.setText( savedInstanceState.getString("numberOfPeopleNumber"));

        radioGroup.check(savedInstanceState.getInt("radioGroupPercent"));


    }

    public void clearHistory(View v){

        tipAmountNumberEditText.setText("");
        totalWithTipNumberEditText.setText("");
//        radioGroup.clearCheck();
        billTotalWithTaxNumberInputText.setText("");
        numberOfPeopleNumberInputText.setText("");
        totalPerPersonNumberEditText.setText("");
        overageNumberEditText.setText("");
        radioGroup.clearCheck();


    }
}